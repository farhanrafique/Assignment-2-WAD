<!DOCTYPE html>
<html>
<head>

	<title>WAD-H UCP Assignment 2</title>
	<meta charset="UTF-8">
	<meta name="description" content="UCP Section H Assignment 2">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
	<meta name="author" content="Farhan Rafique">

	<link rel="stylesheet" type="text/css" href="css/bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="images/image.gif">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
	<script type="text/javascript" src="JS/main.js"></script>
	<script type="text/javascript" src="JS/jquery-3.2.1.min.js"></script>

</head>

<body>
	
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
	<div class="container">
	<div class="row">
	<h7 style="color: white">Ucp Johar Town,Lahore | Call us on: +02 00 0000 00000</h7>
</div>
	<div class ="row">
	<h8 style="color: white">Our team | Faq 
		<span>&nbsp &nbsp</span>
	<i class="fa fa-facebook-official"></i>
	<span>&nbsp &nbsp</span>
	<i class="fa fa-twitter"></i>
	<span>&nbsp &nbsp</span>
	<i class="fa fa-linkedin-square"></i>
	<span>&nbsp &nbsp</span>
	<i class="fa fa-printerest"></i></h8>
	</div>

</nav>
<header class="jumbotron text-center">
	<div id="main-nav" class="dark-div nav-style-1">
	<nav class="navbar navbar-inverse main-color-2-bg">
	<div class="container">
		<div class="navbar-header">
		<a class="classess" href="https://www.ucp.edu.pk" title="University of Central Punjab">
		<img src="https://www.ucp.edu.pk/wp-content/uploads/2017/03/ucp-logo.png" alt="University Of Central Punjab">
		</a>
		</div>
	</div>
</nav>
</div>

<nav class="navbar navbar-expand-sm bg-blank navbar-dark navbar-inverse">
	<div class="container" id="farhan">
		<div class="row">
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="nav navbar-nav">
			  <li class="nav-item">
				<a style="color:white"class="dropdown-toggle" data-toggle="dropdown" href="#">Home<span class="caret"></span></a>
			  </li>
			  <span >&nbsp &nbsp</span>
			    <div style="color:#C49D8F" class="dropdown">Pages
			        <i class="fa fa-caret-down"></i>
                      <div class="dropdown-content">
               <a href="#">About Me</a>
               <a href="#">About US</a>
               <a href="#">FAQ</a>
               <a href="#">Meet the Team</a>
               <a href="#">Contact Page 1</a>
               <a href="#">Contact Page 2</a>
               <a href="#">Error Page</a>
                    </div>
               </div> 
			   <span >&nbsp &nbsp</span>
			  <li class="nav-item">
				<a style="color:white" class="dropdown-toggle" data-toggle="dropdown" href="#">Portfolio<span class="caret"></span></a>
			  </li>
			   <span >&nbsp &nbsp</span>
			  <li class="nav-item">
				<a style="color:#C49D8F" class="dropdown-toggle" data-toggle="dropdown" href="#">Blog<span class="caret"></span></a>
			  </li> 
			   <span >&nbsp &nbsp</span>
			  <li class="nav-item">
				<a style="color:white"class="dropdown-toggle" data-toggle="dropdown" href="#">Elements<span class="caret"></span></a>
			  </li> 
			  <span >&nbsp &nbsp</span>
			  <span class="navbar-toggler-icon"></span>
			</ul>
			</div>
		</div>
	</div>
	
</nav>

	<div style="color:white"class="container">
	<div class="row">
	<h1>Hi,UCP<br><small><small><small>Class Activity</small></small></small></h1>
</div>
</div>
			

</header>
<div class="container">
	<div id="he">
<h4 style="margin-left: 450px">What I Can Do</h4></div>
	<div class="row">
		<div class="col-sm-4" id="hell">
			<i class="fa fa-file-text-o">Fully Responsive</i>
			<p>It has roots in a piece of
				classical Latin literature from
				45 BC, making it over 2000 years
				but the majority have suffered alteration
				old.</p>
		</div>
<div class="col-sm-4" id="hel">
	<i class="fa fa-hourglass-half">Powerful Portfolios</i>
		<p>here are many variations of 
			passages of Lorem Ipsum available
			but the majority have suffered alteration
			in some form</p>
</div>

<div class="col-sm-4" id="helo">
	<i class="fa fa-hourglass-half">Amazing ShortCodes</i>
		<p>It is a long established fact that a reader 
			will be distracted by the readable content 
			of a page when looking at its layout
			 The point of using Lorem Ipsum.</p>
</div>

</div>
</div>

<div class="container">
	<div id="hh">
<h4 >Little Bit About Me</h4></div>
<div class="row">
		<div class="col-sm-4">
		<img src="images/index1.jpg" height="95%" width="100%">
</div>
      <div class="col-sm-8">
      	<h2>I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer.</h2><br>
      	<p> Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.</p><br>
      	<p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain.</p>

      	<p>Resume<i class="fa fa-download"></p></i>
      <i class="fa fa-facebook-official"></i>
	  <span>&nbsp &nbsp</span>
	 <i class="fa fa-twitter"></i>
	 <span>&nbsp &nbsp</span>
	 <i class="fa fa-linkedin-square"></i>
	 <span>&nbsp &nbsp</span>
	 <i class="fa fa-printerest"></i>

</div>
</div>
</div>


<div class="container" style="background-color:#E4EFF5">
	<div id="he">
<h4>Thank You</h4></div>
    <div class="row">
     <div class="col-sm-6" id="fani">

		<?php 
		if(isset($_POST['submit'])) //submit is a name in index.php file
		{
			$fname=$_POST['FirstName'];
			$lname=$_POST['LastName'];
			$email=$_POST['Email'];
			$message=$_POST['Message'];

			echo "First Name is:" .$fname."<br>";
			echo "Last Name is:" .$lname."<br>";
			echo "Email is:" .$email."<br>";
			echo "Message is:" .$message."<br>";
		}
		?>
</div>

</div>
</div>
<br>
<br>
<div class="footer" style="background-color: black">
	<div class="container">
		<div class="row">
			<div class="col-sm-3">
				<h2 class="haha">About Me</h2>
				<p>BSCS 5th Semester Student</p>
		<input type="text" name="Search" placeholder="Search...." style="background-color: black"> <i class="fa fa-search"></i>
			</div>
		<br><br><br>

		<div class="col-sm-3">
			<h2 id="word">Connect with Me</h2>
			<p>instagram <br>facebook<br> twitter<br> printerest<br> Vimo</p>
		</div>

				<div class="col-sm-3">
					<h2 id="add_link">Addidional Links</h2>
					<p>Projects<br>Shops<br>Pages<br>About<br>Contat</p>
				</div>

			<div class="col-sm-3">
					<h2 id="contact_me">Contact Me</h2>
					<p>UCP Johat Town, Lahore<br>yourname@yourabc.com<br>Call us on:<br>+92 000000<br>+92 000000<br>+92 000000</p>
				</div>

	</div>
</div>
</div>
</body>
</html>