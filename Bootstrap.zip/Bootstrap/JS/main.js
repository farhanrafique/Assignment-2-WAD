function validate(){
                    var a=document.forms["hello"]["FirstName"].value;
                    var b=document.forms["hello"]["LastName"].value;
					var c=document.forms["hello"]["Email"].value;
					var d=document.forms["hello"]["Message"].value; //hello is a class and Message is name
					var flag="1";

					if(a==null || a==""|| b==null || b=="" || c==null || c=="" || d==null || d=="")
					{
						alert("Please fill out this form");
						flag="0";
					}
					else
					{
						var hello=document.getElementsByClassName("firstname")[0].value; //Firstname is class
						var hello1=document.getElementsByClassName("lastname")[0].value;
						var hello2=document.getElementsByClassName("firstemail")[0].value;
						var hello3=document.getElementsByClassName("Message")[0].value;
								

						var regular;

						if(hello.search(regular)==-1) // I mean null//
						{
							alert("Name should contain only alphabets");
							flag="0";
						}
						if(hello1.search(regular)==-1) // I mean null//
						{
							alert("Name should contain only alphabets");
							flag="0";
						}
						regular1= /@[^0-9]/;
						if(hello2.search(regular1)==-1)
						{
							alert("Please enter  Email @gmail.com");
							flag="0";
						}
						if(hello3.search(regular)==-1)
						{
							alert("Please fill the Message part");
						}
					}
						if(flag=="1")
					{
						alert("Form submitted");
					}

}